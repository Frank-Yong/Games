<?php

return [
       'Reflexes' => 'Agility',
	   'OneonOne' => 'Attention',
	   'Handling' => 'Handling',
	   'Tackling' => 'Dispossesion',
	   'Marking' => 'Marking',
	   'Heading' => 'Head game',
	   'LongShot' => 'Distance shot',
	   'Positioning' => 'Anticipation',
	   'Shooting' => 'Shot',
	   'FirstTouch' => 'Accuracy',
	   'Creativity' => 'Ball Possesion',
	   'Crossing' => 'Launches',
	   'Passing' => 'Passing',
	   'Communication' => 'Talking',
	   'TeamWork' => 'Team Player',
	   'Conditioning' => 'Stamina',
	   'Speed' => 'Speed',
	   'Experience' => 'Experience',
	   'Condition' => 'Ronaldo skill',
	   'Dribbling' => 'Messi skill',
	   'Aggresivity' => 'Warlike',
	   'Age' => 'Age',
	   'Form' => 'Form',
	   'Contract' => 'Contract',
	   
	   //menu
	   'NEWS' => 'NEWS',
	   'TEAM' => 'TEAM',
	   'MESSAGES' => 'MESSAGES',
	   'CLUB' => 'CLUB',
	   'LINE-UP' => 'LINE-UP',
	   'SEARCH' => 'SEARCH',
	   'LOGOUT' => 'LOGOUT',
	   
	   //player
	   'years' => 'y.',
	   
	   //team
	   'Games' => 'Games',
	   'Players' => 'Players',
	   'Sponsors' => 'Sponsors',
	   'Training' => 'Training',
	   'T-shirt no.' => 'T-shirt no.',
	   'Transfers' => 'Transfers',
	   'Stadium' => 'Stadium',
	   'Facilities' => 'Facilities',
	   'Competitions' => 'Competitions',
	   
	   //stadium
	   'Name' => 'Name',
	   'Tickets' => 'Tickets',
	   'Price' => 'Price',
	   'Set' => 'Set',
	   'Under construction' => 'Under construction',
	   'Increase capacity' => 'Increase capacity',
	   'seats' => 'seats'
   ];
?>