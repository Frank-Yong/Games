<a href="alocaTineri.php">New youth players</a> | 
<a href="genBotTeam.php">Generate bot team</a> | 
<a href="jucLiberi.php">Free players</a> |
<a href="antrenoriLiberi.php">Free trainers</a> |
<a href="jucLiberiPremiu.php">Free players - gift</a> |
<a href="genLeague.php">Generate league</a> |
<a href="afisareRezultate.php">Show results</a> |
<a href="changeTeam.php">Replace team</a> |
<a href="MailTo.php">Send mail to users</a> |
---
<a href="genLeagueKO.php">Generate KO leagues (Cups)</a> |

<a href="AlocaTrofeu.php">Trophy allocation</a> |
<a href="echipastart.php">Line-up team</a> |
<a href="setFirst11.php">Make first 11</a> |
<a href="addNews.php">News</a> |
<a href="punepeliber.php">Fire player</a> |
<a href="clasament_activ.php">Activity/League table</a> |
<a href="PremiiSezon.php">Season awards</a> |
<a href="list_injury.php">Injured players</a> |

<a href="DeleteTeam.php">Delete team</a> |

<a href="delJucatoriEchipa.php">Delete players</a>

 ---- ----<a href="login.php">Login</a> |
<a href="logout.php">Logout</a>

<?php
echo '<br/><br/>'.$err_msg.'<br>';
?>