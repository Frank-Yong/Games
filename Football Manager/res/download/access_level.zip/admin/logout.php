<?php
$_CHECK_LOGIN = 0;
include ("../app.conf.php");

unset($_SESSION['USERID']);

include("admin.head.php");

?>
