<?php

return [
       'Reflexes' => 'Agility',
	   'OneonOne' => 'Atention',
	   'Handling' => 'Handling',
	   'Tackling' => 'Dispossesion',
	   'Marking' => 'Marking',
	   'Heading' => 'Head game',
	   'LongShot' => 'Distance shot',
	   'Positioning' => 'Anticipation',
	   'Shooting' => 'Shot',
	   'FirstTouch' => 'Accuracy',
	   'Creativity' => 'Ball Possesion',
	   'Crossing' => 'Launches',
	   'Passing' => 'Passing',
	   'Communication' => 'Talking',
	   'TeamWork' => 'Team Player',
	   'Conditioning' => 'Stamina',
	   'Speed' => 'Speed',
	   'Experience' => 'Experience',
	   'Condition' => 'Ronaldo skill',
	   'Dribbling' => 'Messi skill',
	   'Aggresivity' => 'Warlike'
   ];
?>