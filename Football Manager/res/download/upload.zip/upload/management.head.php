<table>
<tr>
<td>
<a href= "index.php?option=management"><img src="images/bani.png" width="60"></a>
</td>
<TD>
<a href= "index.php?option=calendar"><img src="images/calendar.png" width="60"></a>
</TD>
<TD>
<a href= "index.php?option=modificaCont"><img src="images/change.png" width="85"></a>
</TD>
</tr>
<tr>
<td align="center">Spent</td>
<td align="center">Calendar</td>
<td align="center">My account</td>
</tr>
</table>
